package flights.generator;

public enum FlightStatus {
    SCHEDULED,
    LANDED,
    LATE,
    CANCELED
}
